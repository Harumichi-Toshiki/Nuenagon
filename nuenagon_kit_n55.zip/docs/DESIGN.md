# Shikibu / Nuenagon 設計書 v1.6

- 作成日：2026-10-20（v1.1〜v1.4：2026-10-21、v1.5・v1.6：2026-10-22）
- 作者：Harumichi-Toshiki
- 対象：Shikibu（学習器）と Nuenagon（αβ探索エンジン）を実装する Claude Code
- 同じ文書を両リポジトリの `docs/DESIGN.md` に置く。**両者の内容は常に完全に一致していなければならない。**

---

## 0. 概要

### 0.1 何を作るか

| 名前 | 役割 | 言語 | リポジトリ |
|---|---|---|---|
| **Shikibu**（式部） | Nuenagon 用評価関数の学習器 | Rust（データ・特徴量）＋ Python/PyTorch（学習） | `Shikibu` |
| **Nuenagon** | 独自の高速評価関数で動く αβ探索の USI エンジン | C++ | `Nuenagon` |
| Dajo（太政） | Dainagon（DL・MCTS）と Nuenagon の合議 | — | `Dajo`（**本書の対象外**） |

- Nuenagon は**単体の USI エンジン**として動き、将棋所・ShogiGUI に登録できること。
- Dajo は別リポジトリで、Dainagon と Nuenagon を呼び出して束ねる。本書では、両エンジンと Dajo の間の約束（USI の範囲：§E7、Dajo プロトコル DJP v0：§E9）を定める。

### 0.2 開発方針

1. **フロムスクラッチ**。既存の将棋 NNUE 実装・学習器（やねうら王、nnue-pytorch、bullet、bullet-shogi、tatara、BulletOu など）の**コードをコピーしない**。一般的な技法（疎入力の和、差分更新、量子化、SIMD）の考え方を使うのは可。HalfKP など、玉位置で条件付けする既存の特徴量設計は使わない。
2. **最優先は「特徴量が両リポジトリで1ビットも違わないこと」と「凍結区画を二度と変えなくて済むこと」**。エンジンの効率はその次。
3. 両リポジトリをまたぐ自動テストは作らない。一致は**本書に載せた正解データ（§F7・付録B）に各自が合わせる**ことで保証する。

### 0.3 本書の構成と変更ルール

| 区画 | 内容 | 変更 |
|---|---|---|
| **凍結区画（第F部）** | 座標、特徴量、ネットワークの計算式、重みファイル形式、評価値スケールの扱い、正解データ | **変更禁止** |
| 自由区画（第S部・第E部） | 学習器の内部、探索、高速化、量子化の実装 | 本書の要件を満たす範囲で自由 |

- 凍結区画に変更が必要になった場合、**既存の定義を書き換えず、新しい ID（例：`RayPair_v2`）として追加する**。既存 ID の意味は永久に変わらない。
- 本書の改訂は Michi（Harumichi-Toshiki）が行い、両リポジトリへ同時に反映する。Claude Code が凍結区画に疑問や矛盾を見つけた場合は、**自分で解釈を決めずに作業を止めて報告する**。

### 0.4 用語

| 用語 | 意味 |
|---|---|
| 視点（perspective） | 特徴量を作る側。先手視点と後手視点の2つを毎局面作る |
| 手番側 / 非手番側 | 局面で次に指す側 / そうでない側 |
| 特徴インデックス | 特徴量ベクトルの中で ON になっている要素の番号 |
| 蓄積値（accumulator） | 第1層の出力。ON の特徴の重みの和＋バイアス |
| 教師スケール（eval_scale） | 教師評価値 cp を勝率に変換する定数。`勝率 = sigmoid(cp / eval_scale)` |

---

# 第F部　凍結区画（変更禁止）

## F1. 座標と駒の約束事

### F1.1 絶対座標

- マスを `(y, x)` で表す。`y` = 段、`x` = 筋。
  - `y = 0..8` は 一段目〜九段目（USI の `a`〜`i`）。
  - `x = 0..8` は 9筋〜1筋。
- USI のマス `<筋><段>`（例：`7g`）は `x = 9 − 筋`、`y = 段 − 'a'` に対応する。`7g` → `(y, x) = (6, 2)`。
- SFEN の盤面文字列は一段目から順に、各段を9筋から1筋の順（`x` が増える順）に並べたもの。
- 先手の駒は `y` が減る方向へ進む。

### F1.2 視点座標

- **先手視点**：絶対座標そのまま。
- **後手視点**：盤を180°回転し、先後を入れ替える。絶対座標 `(y, x)` は視点座標 `(8 − y, 8 − x)` になり、後手の駒が「視点側の駒」、先手の駒が「相手側の駒」になる。持ち駒も同様に入れ替える。
- 視点側の駒は、どちらの視点でも `y` が減る方向へ進む。
- **以降、特徴量の定義はすべて視点座標で行う。** マス番号は `sq = y*9 + x`（0〜80）。

### F1.3 駒番号 `pc`（0〜27）

| pc（視点側） | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 駒 | 歩 | 香 | 桂 | 銀 | 金 | 角 | 飛 | 玉 | と | 成香 | 成桂 | 成銀 | 馬 | 竜 |

相手側の駒は上の番号に **+14**（例：相手の歩 = 14、相手の玉 = 21、相手の竜 = 27）。

### F1.4 持ち駒の駒種番号 `h`（0〜6）と上限

| h | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|---|
| 駒 | 歩 | 香 | 桂 | 銀 | 金 | 角 | 飛 |
| 上限枚数 `max[h]` | 18 | 4 | 4 | 4 | 4 | 2 | 2 |
| オフセット `off[h]` | 0 | 18 | 22 | 26 | 30 | 34 | 36 |

---

## F2. 特徴量

### F2.0 共通ルール（重要）

1. 特徴量は**視点ごと**に作る。1局面につき「先手視点の特徴」と「後手視点の特徴」の2組がある。
2. 特徴は**重複を許す多重集合**である。同じインデックスが複数回現れることがあり（例：別々の筋で同じ駒の対が同じ距離で並ぶ）、**出現回数ぶん加算する**。重複を除いてはならない。
3. 1局面1視点で ON になる特徴の数は最大 **208** 個（A1＋A2 ≤ 40、B1 ≤ 160、B2 ≤ 8）。
4. 玉が盤上にない局面は扱わない（入力の妥当性検査で弾いてよい）。

### F2.1 特徴セット `RayPair_v0`（15,000 次元）

| 区間 | 名前 | 範囲 |
|---|---|---|
| A1 | 駒位置 | [0, 2268) |
| A2 | 持ち駒 | [2268, 2344) |
| B1 | ライン隣接対 | [2344, 14888) |
| B2 | 桂の利き | [14888, 15000) |

#### A1 駒位置

盤上のすべての駒（玉を含む）について：

```
idx = pc*81 + sq
```

#### A2 持ち駒（序数表現）

`side` = 0（視点側の持ち駒）／1（相手側の持ち駒）。駒種 `h` を `n` 枚持っていれば、`k = 0, 1, …, n−1` のすべてについて：

```
idx = 2268 + side*38 + off[h] + k
```

#### B1 ライン隣接対

4本の軸を、次の走査規則で定義する。

| axis | ラインの決め方 | 走査方向（手前 → 奥） | 距離 d |
|---|---|---|---|
| 0（縦） | `x` が同じマスの集合 | `y` 増加 | `y_hi − y_lo` |
| 1（横） | `y` が同じマスの集合 | `x` 増加 | `x_hi − x_lo` |
| 2（斜め↘） | `x − y` が同じマスの集合 | `y` 増加（`x` も増加） | `y_hi − y_lo` |
| 3（斜め↙） | `x + y` が同じマスの集合 | `y` 増加（`x` は減少） | `y_hi − y_lo` |

各ラインについて：

1. ライン上の駒のあるマスを、走査方向の順に並べる。
2. **連続する2つ**（間に駒がない隣同士）を `(lo, hi)` とする。`lo` が走査で先に現れる方。
3. 各組について、距離 `d`（上の表、常に1以上）を距離区分 `db` に変換する：

   | d | 1 | 2 | 3, 4 | 5 以上 |
   |---|---|---|---|---|
   | db | 0 | 1 | 2 | 3 |

4. 次のインデックスを ON にする（`pc_lo`, `pc_hi` は各マスの駒番号）：

```
idx = 2344 + pc_lo*448 + pc_hi*16 + axis*4 + db
```

- 対は**順序付き**である。`(歩, 金)` と `(金, 歩)` は別のインデックス。
- 同じ2駒を逆向きにもう一度数えることはしない（各組は1回だけ）。
- 駒が1つ以下のラインからは何も出ない。

#### B2 桂の利き

盤上の**成っていない桂**（pc = 2 または 16）それぞれについて：

- `s` = 0（視点側の桂、pc = 2）／1（相手側の桂、pc = 16）。
- 跳び先：`s = 0` なら `ty = y − 2`、`s = 1` なら `ty = y + 2`。`(ty, x − 1)` を `lr = 0`、`(ty, x + 1)` を `lr = 1` とする。
- 跳び先が盤内で、かつ**駒があれば**（どちらの駒でも、玉でもよい）、その駒の番号を `pc_t` として：

```
idx = 14888 + s*56 + pc_t*2 + lr
```

### F2.2 特徴セット `RayPair_v1`（115,352 次元）

`RayPair_v0` の B1 に「領域」を掛け合わせたもの。**A1・A2・B2 の定義は v0 と同じで、B2 の開始位置だけが変わる。**

| 区間 | 名前 | 範囲 |
|---|---|---|
| A1 | 駒位置 | [0, 2268) |
| A2 | 持ち駒 | [2268, 2344) |
| B1 | 領域付きライン隣接対 | [2344, 115240) |
| B2 | 桂の利き | [115240, 115352) |

B1 の対ごとに、**`lo` のマス**から領域 `region`（0〜8）を求める：

```
region = (y_lo / 3)*3 + (x_lo / 3)          # 整数の切り捨て除算
local  = pc_lo*448 + pc_hi*16 + axis*4 + db  # v0 と同じ（0〜12543）
idx_B1 = 2344 + region*12544 + local
idx_B2 = 115240 + s*56 + pc_t*2 + lr
```

### F2.3 手計算できる例（RayPair_v0、先手視点）

局面 `4k4/9/9/9/9/9/3p5/9/2N1K4 b 2Pg 1`
（先手：玉 5i、桂 7i、持ち駒 歩2／後手：玉 5a、歩 6g、持ち駒 金1）

| 特徴 | 内容 | 計算 | idx |
|---|---|---|---|
| A1 | 視点側の桂 (8,2) | 2*81 + 74 | 236 |
| A1 | 視点側の玉 (8,4) | 7*81 + 76 | 643 |
| A1 | 相手の歩 (6,3) | 14*81 + 57 | 1191 |
| A1 | 相手の玉 (0,4) | 21*81 + 4 | 1705 |
| A2 | 視点側 歩 1枚目・2枚目 | 2268 + 0 + 0 + {0,1} | 2268, 2269 |
| A2 | 相手側 金 1枚目 | 2268 + 38 + 30 + 0 | 2336 |
| B1 | 横 y=8：桂(8,2)→玉(8,4)、d=2 | 2344 + 2*448 + 7*16 + 1*4 + 1 | 3357 |
| B1 | 縦 x=4：相手玉(0,4)→玉(8,4)、d=8 | 2344 + 21*448 + 7*16 + 0*4 + 3 | 11867 |
| B2 | 桂(8,2) の跳び先 (6,3) に相手の歩、lr=1 | 14888 + 0*56 + 14*2 + 1 | 14917 |

結果（昇順）：`236,643,1191,1705,2268,2269,2336,3357,11867,14917`

同じ局面の `RayPair_v1`（持ち駒なし版 `4k4/9/9/9/9/9/3p5/9/2N1K4 b - 1`）：
`236,643,1191,1705,24411,78621,115269`
（例：縦の対は lo = 相手玉 (0,4) なので region = 1、`2344 + 1*12544 + 9523 = 24411`）

---

## F3. ネットワーク

### F3.1 ID と構成

| ネットワーク ID | 特徴セット | 第1層の幅 W | L1 | L2 |
|---|---|---|---|---|
| `RayPair_v0Network` | `RayPair_v0` | 128 | 16 | 16 |
| `RayPair_v1Network` | `RayPair_v1` | 128 | 32 | 32 |

W・L1・L2 は重みファイルのヘッダ（§F4）に記録される。エンジンはヘッダの値に従う（ただし、未対応の組み合わせなら読み込みを拒否してよい）。

### F3.2 計算式（float32 の定義）

視点 `q` の特徴の多重集合を `F_q` とする。

```
acc_q = ft_bias + Σ_{i ∈ F_q（重複込み）} ft_weight[i]     # 長さ W、q = 手番側, 非手番側
x     = concat(acc_手番側, acc_非手番側)                    # 長さ 2W。必ず手番側が先
h0    = clamp(x, 0, 1)
h1    = clamp(l1_weight · h0 + l1_bias, 0, 1)              # 長さ L1
h2    = clamp(l2_weight · h1 + l2_bias, 0, 1)              # 長さ L2
z     = out_weight · h2 + out_bias                         # スカラー
```

- `ft_weight`・`ft_bias` は先手視点・後手視点で**共有**する。
- `z` は**手番側から見た勝率のロジット**。手番側の勝率は `sigmoid(z)`。
- 評価値（cp、手番側から見た値）は `z × eval_scale`（§F5）。

### F3.3 学習時の重みの範囲（学習器が守る約束）

学習器は、オプティマイザの各ステップの後に次のクリップを行う。エンジンの量子化（§E4）はこの範囲を前提にする。

| パラメータ | 範囲 |
|---|---|
| `ft_weight`, `ft_bias` | [−1, 1] |
| `l1_weight`, `l2_weight`, `out_weight` | [−127/64, 127/64] |
| `l1_bias`, `l2_bias`, `out_bias` | 制限なし |

---

## F4. 重みファイル形式（拡張子 `.shk`）

すべてリトルエンディアン。

### F4.1 ヘッダ（180 バイト）

| オフセット | 型 | 内容 |
|---|---|---|
| 0 | char[8] | マジック `SHIKIBU\0` |
| 8 | u32 | 形式バージョン = 1 |
| 12 | char[32] | 特徴セット ID（ASCII、残りは `\0` で埋める）例：`RayPair_v0` |
| 44 | char[32] | ネットワーク ID（同上）例：`RayPair_v0Network` |
| 76 | u32 | 特徴量の次元数（v0 = 15000、v1 = 115352） |
| 80 | u32 | W |
| 84 | u32 | L1 |
| 88 | u32 | L2 |
| 92 | f32 | eval_scale（§F5） |
| 96 | f32 | 学習に使った λ（記録用） |
| 100 | u64 | 学習した局面数（記録用） |
| 108 | u8[64] | 予約（すべて 0） |
| 172 | u64 | 本体のバイト数 |

### F4.2 本体（float32 の配列を、この順に隙間なく並べる）

| 順 | 名前 | 形（行優先） |
|---|---|---|
| 1 | `ft_weight` | [次元数][W] |
| 2 | `ft_bias` | [W] |
| 3 | `l1_weight` | [L1][2W] |
| 4 | `l1_bias` | [L1] |
| 5 | `l2_weight` | [L2][L1] |
| 6 | `l2_bias` | [L2] |
| 7 | `out_weight` | [1][L2] |
| 8 | `out_bias` | [1] |

- `l1_weight[j][k]` は、出力 j に対する入力 k（`x` の k 番目、つまり 0..W−1 が手番側、W..2W−1 が非手番側）の重み。PyTorch の `nn.Linear.weight` と同じ並び。

### F4.3 フッタ

| 型 | 内容 |
|---|---|
| u32 | 本体の CRC32（IEEE 802.3、zlib の `crc32` と同じ） |

エンジンは、マジック・形式バージョン・ID・次元数・本体のバイト数・CRC32 をすべて検査し、1つでも合わなければ読み込みを失敗させる（§E2.3）。

---

## F5. 評価値スケール（eval_scale）

- 教師データ（他のエンジンの評価値を付けた PSV）の評価値のスケールは、PSV に記録されていないため一般に不明である。そこで、**学習器がデータから推定する**（推定方法は §S4）。
- 推定値、または手動で指定した値をヘッダの `eval_scale` に書く。学習時の教師勝率は `sigmoid(score / eval_scale)` で作る。
- エンジンは評価値を `cp = z × eval_scale` で計算する。こうすると Nuenagon の cp が教師と同じ尺度になる。
- エンジンは USI オプション `EvalScale` で上書きできる（0 のときはファイルの値を使う）。

---

## F6. 正解データの判定方法

- 特徴インデックスの列は、**昇順に並べ替え（重複はそのまま残す）**、10進数をカンマ区切りで連結した文字列（空白なし）にする。例：`236,643,1191`
- その文字列の UTF-8 バイト列の SHA-256 を16進数で表し、先頭16文字を「ハッシュ」とする。
- §F7 と付録Bの値に、**総数・区間ごとの個数・総和・ハッシュ・全リストがすべて一致**すれば合格。

## F7. 正解データ

### F7.1 局面

| ID | 内容 | SFEN |
|---|---|---|
| P1 | 平手初期局面 | `lnsgkgsnl/1r5b1/ppppppppp/9/9/9/PPPPPPPPP/1B5R1/LNSGKGSNL b - 1` |
| P2 | 初手▲7六歩の後（後手番） | `lnsgkgsnl/1r5b1/ppppppppp/9/9/2P6/PP1PPPPPP/1B5R1/LNSGKGSNL w - 2` |
| P3 | 中盤（後手番・双方角持ち・桂跳ね） | `ln1g3nl/1r2k1g2/p1psppsp1/1p4p1p/4N4/2P3P2/PP1PPP1PP/1SG2S1R1/L2K1G1NL w Bbp 40` |
| P4 | 終盤（先手番・王手・と金/竜/持ち駒多数） | `l6nl/4+P1gk1/3p1s1p1/p1n1p1p1p/1p1PN4/P1P1P1PP1/1PS2+r2P/2G1K4/LN6L b RBG2SPbgp 89` |

### F7.2 期待値

| 特徴量 | 局面 | 視点 | 総数 | A1 | A2 | B1 | B2 | 種類数 | 総和 | SHA-256先頭16桁 |
|---|---|---|---|---|---|---|---|---|---|---|
| RayPair_v0 | P1 | 先手 | 159 | 40 | 0 | 111 | 8 | 115 | 923378 | `2ceb5ca59bd84bd1` |
| RayPair_v0 | P1 | 後手 | 159 | 40 | 0 | 111 | 8 | 115 | 923378 | `2ceb5ca59bd84bd1` |
| RayPair_v0 | P2 | 先手 | 157 | 40 | 0 | 110 | 7 | 118 | 906022 | `549ac43d5f0f687e` |
| RayPair_v0 | P2 | 後手 | 157 | 40 | 0 | 110 | 7 | 118 | 896437 | `a8702be307a13afe` |
| RayPair_v0 | P3 | 先手 | 145 | 37 | 3 | 99 | 6 | 122 | 798715 | `f5691da91a69e73f` |
| RayPair_v0 | P3 | 後手 | 145 | 37 | 3 | 99 | 6 | 122 | 827787 | `497b9589e5d8c2b2` |
| RayPair_v0 | P4 | 先手 | 125 | 31 | 9 | 82 | 3 | 110 | 651401 | `2e5295e42acf0ffb` |
| RayPair_v0 | P4 | 後手 | 125 | 31 | 9 | 82 | 3 | 110 | 667940 | `663376441e74079c` |
| RayPair_v1 | P1 | 先手 | 159 | 40 | 0 | 111 | 8 | 129 | 6505458 | `7304bcf276f589bf` |
| RayPair_v1 | P1 | 後手 | 159 | 40 | 0 | 111 | 8 | 129 | 6505458 | `7304bcf276f589bf` |
| RayPair_v1 | P2 | 先手 | 157 | 40 | 0 | 110 | 7 | 131 | 6199590 | `65e76740c1e824fc` |
| RayPair_v1 | P2 | 後手 | 157 | 40 | 0 | 110 | 7 | 133 | 6428341 | `0d8e1a2ffbc2da22` |
| RayPair_v1 | P3 | 先手 | 145 | 37 | 3 | 99 | 6 | 142 | 5690875 | `e0099dac40fdb74c` |
| RayPair_v1 | P3 | 後手 | 145 | 37 | 3 | 99 | 6 | 141 | 5431435 | `8a2453770e61a1b5` |
| RayPair_v1 | P4 | 先手 | 125 | 31 | 9 | 82 | 3 | 122 | 4364425 | `d524fd37cfe02875` |
| RayPair_v1 | P4 | 後手 | 125 | 31 | 9 | 82 | 3 | 124 | 4506404 | `6f689e2179fa03f4` |

- 全リストは付録Bにある。
- 「種類数」は重複を除いた異なるインデックスの数（参考値）。
- P1 は先後対称なので、先手視点と後手視点が一致する。
- 参照実装（付録A）では、すべての局面について「局面を180°回転・先後入れ替えした局面の後手視点の特徴 ＝ 元の局面の先手視点の特徴」が成り立つことも確認済み。

---

# 第S部　Shikibu（学習器）

## S1. 構成

```
Shikibu/
  docs/DESIGN.md              # 本書
  crates/
    shk_feat/                 # PackedSfen のデコード、盤面、特徴抽出（RayPair_v0 / v1）
    shk_loader/               # 多スレッドの読み込み・シャッフル・バッチ生成（pyo3 で Python へ）
    shk_tools/                # CLI：データ統計、eval_scale 推定、シャッフル、シャード分割
  python/shikibu/
    features.py               # Rust 拡張の薄いラッパ
    networks/                 # ネットワーク登録（名前 → クラス）
      raypair_v0.py           # RayPair_v0Network
      raypair_v1.py           # RayPair_v1Network
    train.py
    export.py                 # §F4 形式の書き出し
    quantsim.py               # 量子化の影響を測る確認用ツール（§S7）
  reference/raypair_ref.py    # 付録Aの参照実装（そのまま置く）
  configs/*.toml
  notebooks/colab_train.ipynb
  tests/
  bench/
```

- Rust 側は pyo3 + maturin でビルドし、Python から呼ぶ。
- **差し替え可能な構造**：
  - 特徴セットは Rust の共通トレイト（次元数を返す、局面と視点から全インデックスを出す）を実装すれば追加できる。追加には再ビルドが必要。
  - ネットワークは Python 側でクラスを名前で登録する。追加に再ビルドは不要。
  - どれを使うかは設定ファイル（TOML）で選ぶ。ネットワークと特徴セットの組み合わせが §F3.1 と違う場合は起動時にエラーにする。

## S2. 入力データ：PSV（PackedSfenValue、1局面40バイト）

| オフセット | 型 | 内容 |
|---|---|---|
| 0 | 32 bytes | PackedSfen（やねうら王形式の局面圧縮） |
| 32 | i16 | score（手番側から見た評価値） |
| 34 | u16 | move（学習には使わない） |
| 36 | u16 | gamePly |
| 38 | i8 | game_result（手番側から見て 1 = 勝、0 = 引分、−1 = 負） |
| 39 | u8 | padding |

- PackedSfen のデコーダは Rust で自作する。**正しさの基準は cshogi**（`Board.set_psfen`）とし、テストで照合する（§S8-1）。
- 総量は使うデータによる。数十億局面の規模を想定する（1局面40バイトなので、10億局面で約40GB）。

## S3. データパイプライン

### S3.1 事前シャッフル（手元のPCで1回だけ実行）

`shk_tools shuffle` を用意する。

1. 全ファイルを読みながら、各局面をランダムに K 個のバケツファイルへ振り分ける（K はメモリに収まるよう自動で決める）。
2. 各バケツをメモリ上でシャッフルする。
3. **1GB（25,000,000局面）単位のシャード**として書き出す。ファイル名は `shard_00000.psv` のような連番。
4. 最後のシャード1つを**検証用**として学習から除外する（設定で指定）。

### S3.2 学習中の読み込み（Colab）

- シャードは Google Drive に置く。学習中、別スレッドが**次のシャードを Drive から Colab のローカル SSD へ連続コピー**しておき、使い終わったシャードは削除する。ローカルに置くのは同時に3〜4個まで。
- 2〜3シャードぶんの局面をメモリ上のシャッフルバッファで混ぜてからバッチにする。
- 必要な帯域は 毎秒100万局面 × 40バイト = 40MB/s。コピー速度を計測してログに出し、足りない場合は報告する（代替として Google Cloud Storage から読む経路を用意してよい）。

### S3.3 バッチの形式（Rust → PyTorch）

バッチごとに次を返す。

- 手番側視点：`indices`（int64、全局面ぶんを連結）、`offsets`（int64）
- 非手番側視点：同上
- `score`（float32）、`result`（float32：勝 = 1、引分 = 0.5、負 = 0）

`indices`・`offsets` は `nn.EmbeddingBag(mode='sum')` にそのまま渡せる形式とし、**重複したインデックスはそのまま含める**（§F2.0）。

## S4. データ統計と eval_scale の推定

学習の前に `shk_tools stats` を実行し、次を報告する。

1. `game_result` の分布（1 / 0 / −1 の割合）、`score` の分布、`gamePly` の分布。
2. **勝敗ラベルが使えるかの判定**：`game_result == 0` が95%を超える場合は「勝敗が記録されていない」とみなす。この場合、eval_scale は推定できないので、**処理を止めて報告**し、手動指定（`--eval-scale`）と λ = 1.0 での学習を求める。
3. **eval_scale の推定**（勝敗が使える場合）：
   - シャッフル済みデータから1,000万局面を取る。`|score| ≥ 30000` の局面は除く。
   - 目的関数：`mean BCE(sigmoid(score / S), r)`。ここで `r` は勝 = 1、引分 = 0.5、負 = 0。
   - `S` を [50, 5000] の範囲で、log S についての黄金分割探索で最小化する。
   - 得られた `S` と、そのときの BCE を報告する。
4. 推定値（または手動の指定値）を設定ファイルに書き、学習と重みファイルのヘッダの両方で使う。

## S5. ネットワークの実装

- 第1層は `nn.EmbeddingBag(次元数, W, mode='sum')` と、別の bias パラメータ（長さ W）で実装する。両視点で同じモジュールを使う。
- 計算は §F3.2 の通り。手番側を先に連結すること。
- 初期化：`ft_weight` は N(0, 0.01²)、Linear は PyTorch の既定値。

## S6. 学習

| 項目 | 既定値 |
|---|---|
| 教師勝率 | `p_t = sigmoid(score / eval_scale)` |
| 目標 | `t = λ*p_t + (1 − λ)*result`、λ = 0.75（勝敗が使えない場合は 1.0） |
| 損失 | `BCEWithLogits(z, t)` |
| オプティマイザ | AdamW。weight decay は Linear の weight のみ（ft と bias は 0） |
| 学習率 | ウォームアップ＋コサイン減衰。総ステップ数は設定値 |
| バッチサイズ | 16,384 |
| 重みのクリップ | 各ステップ後に §F3.3 |
| 評価値フィルタ | 既定で無効（設定で `|score|` の上限を指定可能） |

- **保存と再開**：N分ごと（既定30分）に Drive へ保存する。保存内容はモデル、オプティマイザ、スケジューラ、乱数状態、読み込み位置（シャード番号とシャード内の位置）。`--resume` でそこから再開する。
- **検証**：検証用シャードの先頭10万局面で、損失と、教師勝率との MSE を定期的に出力する。

## S7. 書き出しと量子化の確認

- `export.py` は §F4 の形式で `.shk` を書き出す。書き出し直後に読み直し、CRC32 と全テンソルが一致することを確認する。
- `quantsim.py` は §E4 の量子化規則を Python で再現し、検証用局面で「float32 の z」と「量子化後の z」の差（平均・最大）と、損失の悪化を報告する。**これは確認用の道具であり、凍結区画ではない。**

## S8. テスト（必須）

1. **デコーダ照合**：10万局面以上で、自作デコーダの SFEN（盤面・手番・持ち駒）が cshogi と一致すること。
2. **正解データ**：§F7 の全局面・全視点・v0/v1 で、総数・区間ごとの個数・総和・ハッシュ・全リスト（付録B）が一致すること。§F2.3 の手計算例も一致すること。
3. **参照実装との照合**：ランダムに選んだ10万局面で、Rust の特徴抽出と付録Aの参照実装（`reference/raypair_ref.py`）の結果（昇順・重複込み）が一致すること。
4. **視点対称性**：同じ10万局面で、「元の局面の先手視点」＝「180°回転・先後入れ替えした局面の後手視点」となること。
5. **範囲**：全インデックスが次元数未満で、1局面1視点あたりの個数が 208 以下であること。
6. **書き出し**：ダミーの重みを書き出して読み直し、ヘッダと本体が一致すること。

## S9. 性能目標

- Colab L4 ランタイムで**毎秒100万局面以上**。`bench/` で「読み込み＋特徴抽出のみ」と「学習込み」を分けて計測し、報告する。
- GPU 側が律速になった場合に限り、第1層を自前カーネル（Triton など）に置き換えてよい。

## S10. 進め方

| マイルストーン | 内容 |
|---|---|
| M1 | デコーダ、特徴抽出（v0 / v1）、テスト1〜5 |
| M2 | 統計・eval_scale 推定・シャッフルの各ツール、ローダー、ベンチマーク |
| M3 | 学習、保存と再開、Colab ノートブック |
| M4 | 書き出し、quantsim、テスト6 |

各マイルストーンの完了時に、テスト結果とベンチマークの数値を報告すること。

---

# 第E部　Nuenagon（エンジン）

## E1. 構成と土台

- C++（C++17 以上）。主な対象は Windows（大会・将棋所・ShogiGUI）だが、Linux（クラウド）でもビルドできること。
- **盤面表現・指し手生成・詰み探索は Dainagon のエンジンソースを流用してよい。改造も自由。**
- ビルドは AVX2 版を基本とし、AVX-512 版は任意。

```
Nuenagon/
  docs/DESIGN.md        # 本書
  src/
    board/              # 盤面・指し手生成（Dainagon から流用）
    eval/raypair/       # 特徴量（全計算・差分更新）、重みの読み込み、量子化、推論
    search/             # αβ探索（ジョブ、スレッドプール、手ごとの記録、ヒント、パスの探索）
    mate/               # 詰み探索（Dainagon から流用）
    usi/                # USI プロトコル（ponder を含む）
    djp/                # Dajo プロトコル（§E9）
    sys/                # CPU の構成の取得、スレッドの論理CPUへの固定
  tests/
  bench/
```

## E2. USI

### E2.1 対応コマンド

`usi`, `isready`, `setoption`, `usinewgame`, `position`（`startpos` / `sfen`、`moves` 付き）, `go`（`btime` `wtime` `byoyomi` `binc` `winc` `infinite` `ponder` `nodes` `depth` `mate`）, `stop`, `ponderhit`, `gameover`, `quit`

- `usi` への応答：`id name Nuenagon`、`id author Harumichi-Toshiki`、オプション一覧、`usiok`。
- 指し手が無い（負け）ときは `bestmove resign`、入玉宣言勝ちの条件を満たすときは `bestmove win`。
- `USI_Ponder` が true で、読み筋が2手以上あるときは `bestmove <手> ponder <相手の予想手>` と返す。

### E2.2 ponder（相手の手番中の先読み）

USI の標準どおりに実装する。

1. GUI から `position … moves … <自分の手> <相手の予想手>` と `go ponder <持ち時間の指定>` が来たら、その局面の探索を始める。**時間の制限はかけない**（`infinite` と同じ扱い）。`bestmove` は出さない。
2. `ponderhit` が来たら（予想が当たった）、その時点から、`go ponder` に付いていた持ち時間の指定で通常の時間管理に切り替える。すでに使った時間は、思考時間に含めない（相手の手番中の時間なので）。それまでに読んだ結果はそのまま使う。
3. `stop` が来たら（予想が外れた）、直ちに `bestmove` を返す（GUI は無視する）。置換表の中身は残すので、次の探索で再利用される。
4. ponder 中も `info` は通常どおり出す。

### E2.3 USI オプション

| 名前 | 型 | 既定値 | 内容 |
|---|---|---|---|
| `Threads` | spin | 4（1〜256） | 探索スレッドの数（論理スレッド） |
| `CpuAffinity` | string | `auto` | 探索スレッドを動かす論理CPUの番号。`auto`（OS に任せる）、または `0-7`・`0,2,4,6`・`8-15,24-31` のような範囲と列挙 |
| `UsePhysicalCoresOnly` | check | false | true なら、1つの物理コアにつき論理CPUを1つだけ使う（SMT の兄弟を避ける）。`CpuAffinity` と併用したときは、その範囲の中から選ぶ |
| `USI_Hash` | spin | 256（MB） | 置換表のサイズ |
| `EvalFile` | string | `eval/nuenagon.shk` | 重みファイルのパス |
| `EvalScale` | spin | 0（0〜10000） | 0 ならファイルの eval_scale を使う |
| `NetworkDelay` | spin | 120（ms） | 通信遅延の見込み。思考時間から差し引く |
| `USI_Ponder` | check | false | 先読み |
| `MaxPly` | spin | 0（0〜10000） | 最大手数（この手数に達したら引き分け。0 なら制限なし）。大会の規則に合わせる |
| `DrawValue` | spin | 0（−1000〜1000） | 引き分け（千日手・最大手数）の評価値（手番側から見た cp） |
| `DebugCheckAccumulator` | check | false | 差分更新の検査（§E3.4） |
| `FV_SCALE` | spin | 16（1〜128） | HalfKP の評価関数ファイルを使うときの評価値の割り算の値（§E10） |

### E2.4 CPU の割り当て

1台の PC で Dainagon と Nuenagon を同時に動かすため、Nuenagon が使う CPU を指定できるようにする。

- 起動時に CPU の構成（論理CPUの数、物理コアの数、各論理CPUがどの物理コアに属するか、NUMA ノード、SIMD 命令の対応）を調べ、`isready` の後に `info string` で出す。DJP の `dajo sysinfo` でも返す（§E9.6）。
- 探索スレッドは、`CpuAffinity` と `UsePhysicalCoresOnly` で決まる論理CPUの集合に、1スレッドずつ固定する（Windows：`SetThreadGroupAffinity`、Linux：`pthread_setaffinity_np`）。スレッド数が集合の大きさを超える場合は、集合の中で順に割り当てる。
- 64 を超える論理CPU（Windows のプロセッサグループ）にも対応する。
- 割り当てに失敗しても探索は続ける（`info string` で警告を出し、OS に任せる）。

### E2.5 起動時の動作

`isready` で重みファイルを読み込み、検査（§F4.3）、量子化（§E4）を行ってから `readyok` を返す。読み込み後、次の形式で情報を出す。

```
info string Nuenagon eval: feature=RayPair_v0 network=RayPair_v0Network W=128 L1=16 L2=16 eval_scale=XXX.X (file)
info string Nuenagon cpu: logical=32 physical=16 simd=avx2,avx512,vnni threads=8 affinity=8-15
```

`EvalScale` で上書きした場合は `(option)` と表示する。読み込みに失敗した場合は、理由を `info string` で出し、`readyok` を返さない。

## E3. 評価関数：特徴量と差分更新

### E3.1 全計算

- 局面を設定したとき（`position`）に、§F2 の定義どおり両視点の全特徴を求め、蓄積値を計算する。
- **全計算の実装は §F2 を文字どおりに書いたものとし、付録Bの正解データとの一致テストを通すこと**（§E6-1）。差分更新の正しさは、この全計算との一致で保証する。

### E3.2 差分更新の規則

1手ごとに、両視点それぞれで次を行う。

1. **A1**：移動元の駒を引き、移動先の駒（成った場合は成駒）を足す。駒を取った場合は、取られた駒を引く。駒打ちは移動先を足すだけ。
2. **A2**：駒を取った場合、取った側の持ち駒（成駒を取ったときは成る前の駒種）が `n−1` 枚から `n` 枚に増えるので、序数 `k = n − 1` の特徴を足す。駒を打った場合は、`n` 枚から `n−1` 枚に減るので `k = n − 1` を引く。視点によって `side`（0 / 1）が変わることに注意する。
3. **B1**：その手で駒の有無または種類が変わったマス（移動元と移動先、駒打ちなら移動先だけ）を通る**すべてのライン**（4軸 × マス数、重複するラインは1回）について、**指す前の盤面でそのライン上の B1 特徴を全部引き、指した後の盤面で全部足す**。それ以外のラインの特徴は変わらない。
4. **B2**：指す前の盤面の B2 特徴を全部引き、指した後の盤面の B2 特徴を全部足す（最大8個ずつ）。

- 玉が動いても全計算は不要（玉位置で条件付けしていないため）。
- null move では盤面が変わらないので、蓄積値はそのまま。手番が入れ替わるので、連結の順序（手番側が先）だけが入れ替わる。
- 引く特徴と足す特徴で同じものを打ち消すなどの最適化は自由（結果は同じになる）。

### E3.3 この規則が全計算と厳密に一致する理由

- B1 の特徴はラインごとの特徴の和であり、駒の変わらなかったラインの特徴は変わらない。B2・A1・A2 も同様に、変わる部分だけを入れ替えている。
- 量子化後の蓄積値は int16 の整数の足し引きで、§F3.3 のクリップにより絶対値は最大 208 × 127 ＋ 127 = 26,543 < 32,767 に収まる。**途中で飽和・あふれが起きないので、足し引きの順序によらず結果は全計算と一致する。**

### E3.4 検査

`DebugCheckAccumulator` が true の場合、探索中に一定間隔（例：1,000ノードごと）で差分更新の蓄積値と全計算の蓄積値を比較し、不一致なら局面の SFEN と直前の指し手を `info string` で出して停止する。デバッグビルドでは常に有効にする。

## E4. 量子化と推論（自由区画。初期実装はこの規則に従う）

| 箇所 | 規則 |
|---|---|
| `ft_weight`, `ft_bias` | `round(w × 127)` → int16 |
| 蓄積値 | int16 の和 |
| 第1層の後の活性化 | `clamp(acc, 0, 127)` → uint8（手番側を先に連結して 2W 個） |
| `l1_weight`, `l2_weight`, `out_weight` | `round(w × 64)` を [−127, 127] にクリップ → int8 |
| `l1_bias`, `l2_bias`, `out_bias` | `round(b × 127 × 64)` → int32 |
| 隠れ層の出力 | int32 の積和 ＋ bias を 64 で割る（算術右シフト6）→ `clamp(0, 127)` |
| 最終出力 | `z = (int32 の積和 ＋ out_bias) / (127 × 64)` |
| 評価値 | `cp = round(z × eval_scale)`。詰みの値と重ならないよう ±(詰み値 − 1) にクリップ |

- 負の値は直後の clamp で必ず0になるので、右シフトの丸め方向による差は出ない。
- **round は「0から遠い方への四捨五入」**（C++ の `std::lround`。例：2.5 → 3、−2.5 → −3）。偶数への丸め（Python の `round`、numpy の `rint`）ではない。
- 評価値は倍精度で `cp = round(raw × eval_scale / 8128)` と計算する（`raw` は最終出力の int32、8128 = 127 × 64、`eval_scale` はヘッダの f32 を倍精度にしたもの）。
- この規則の正解データは、Shikibu の `tools/make_engine_golden.py` が作る（Nuenagon の N3 で使う）。
- SIMD 向けの重みの並べ替えは自由。
- 読み込み時の量子化にかかる時間は数ミリ秒の見込み（v0 で約192万要素）。

## E5. 探索の構造（v0 の要件）

探索部は、USI の `go` だけでなく、Dajo からの問い合わせ（§E9 の DJP）に答えられる作りにする。DJP の命令そのものは N6 で実装するが、**以下の構造は N4 の時点で用意しておく**（後から足すと作り直しになるため）。

### E5.1 探索の手法

- 反復深化、aspiration window、PVS（主要変化探索）
- 置換表（`USI_Hash`）
- null move pruning、LMR（遅延着手削減）、王手延長
- 静止探索（駒を取る手、取り返し。王手がかかっている局面では全合法手）
- 指し手の並べ替え：置換表の手、駒を取る手（MVV-LVA）、キラー手、履歴、**ヒント（§E5.5）**
- 詰み探索：Dainagon の詰み探索を流用してよい（§E5.7）
- 千日手（連続王手の千日手を含む）、最大手数（`MaxPly`）、入玉宣言の判定。引き分けの評価は `DrawValue`
- 時間管理：持ち時間＋加算（電竜戦本戦は 先手3分+2秒 ／ 後手10分+2秒）と秒読みに対応。`NetworkDelay` を差し引く。ponder に対応（§E2.2）
- マルチスレッド：Lazy SMP

速度目標は1スレッドあたり250万NPS。ただし本書の優先順位により、**正確さを損なう高速化はしない**。

### E5.2 ジョブとスレッドプール

- 探索は「ジョブ」の単位で行う。ジョブは、局面・種類（§E9.4）・制限（時間・ノード数・深さ）・使うスレッド数の上限・優先度を持つ。USI の `go` もジョブの1つ（番号0）として扱う。
- 探索スレッドは起動時（と `Threads` の変更時）に作るスレッドプールにまとめ、ジョブに割り当てる。1つのジョブの中は Lazy SMP で並列化する。
- 複数のジョブを同時に動かせる。スレッドが足りないときは、優先度の高いジョブから割り当て、残りは待たせる。ジョブが終わったスレッドは、待っているジョブ、または動いているジョブに回す。
- ジョブは外から止められる（`stop`・`dajo cancel`）。止めた時点までの結果を返す。

### E5.3 置換表の共有

- 置換表は全ジョブで共有する。メインの探索で読んだ結果を、検証のジョブがそのまま使えるようにするため。
- 世代（generation）を持ち、`usinewgame`・新しい局面での探索開始のたびに進める。古い世代の項目から置き換える。
- パスした局面（§E5.6）の項目は、通常の局面と区別できるように、ハッシュ値に「パス済み」の印を混ぜる。

### E5.4 ルートの手ごとの記録

ルートの各合法手について、次を持つ。

| 項目 | 内容 |
|---|---|
| `score` | 評価値（手番側から見た cp、内部の単位） |
| `bound` | `exact`（正確な値）／`lower`（これ以上）／`upper`（これ以下） |
| `depth` | その値を得た深さ（反復深化の段） |
| `seldepth` | 最大の深さ |
| `pv` | 読み筋 |
| `nodes` | その手に使ったノード数 |

この記録の上に、次の機能を作る。

- **MultiPV**：上位 k 手を正確な値で求める。
- **読む手の限定**：指定した手だけを読む（`searchmoves`）／指定した手を除く（`exclude`）。
- **検証（probe）**：ある手の評価が閾値 T 以上かを、窓 [T−1, T] のゼロ幅探索で確かめる。反復深化で深くしながら、結果を「はい（下限 ≥ T）／いいえ（上限 < T）」として、深さとともに返す。「いいえ」のときは、相手の咎める手順を読み筋として返す。
- **手ごとの正確な評価（rank）**：指定した手すべてを、同じ深さまで正確な値で求める（指定した手の数を k とした MultiPV と同じ）。

### E5.5 ヒント（外部からの方策）

- 局面（ハッシュ値）ごとに「手 → 確率」の表を持てるようにする（ヒントの表）。Dajo が `dajo hint`（§E9.5）で渡す。
- 使い方：
  1. 指し手の並べ替え：置換表の手、得な駒取りの次に、確率の高い順に読む。
  2. LMR：確率が `hint_lmr_threshold`（既定 0.10）以上の手は減らさない。
  3. ルートの最初の反復の順番。
- ヒントの影響の強さは設定で変えられる（`dajo set hint_weight`。0 なら使わない）。ヒントは評価値そのものは変えない（並べ替えと枝刈りだけ）。
- 表は `dajo hint clear`、`usinewgame` で消す。大きさには上限を設け（既定 65,536 局面）、古いものから捨てる。

### E5.6 パスの探索

- 「手番をパスした局面」（null move を指した局面）を、ジョブの起点にできるようにする。脅威の検出（threat）と、詰めろの検出（パスした後に相手の詰みがあるか）に使う。
- 王手がかかっている局面ではパスできない（その場合のジョブはエラーを返す）。
- 千日手の判定では、パスを1手として数えない。

### E5.7 詰み探索

- 詰み専用の探索（df-pn など）をジョブとして動かせるようにする。Dainagon の詰み探索を流用してよい。
- 「手番側の詰み」と、「パスした後の相手の詰み（＝詰めろ）」の両方を調べられること。
- 通常の探索でも、浅い詰み（1手・3手詰め程度）は各節点で調べてよい（実装は自由）。

### E5.8 出来事の通知

探索の中で次の出来事が起きたときに、通知を出せるようにする（USI では `info`、DJP では `dajo event`）。

| 出来事 | 条件 |
|---|---|
| 反復の完了 | 反復深化の1段が終わった |
| 最善手の交代 | 最善手が前の段と変わった |
| 詰みの発見 | 詰みの評価値が出た（自分の勝ち・負けの両方） |
| 評価の急変 | 最善の評価値が前の段から `swing` cp（既定150）以上変わった |
| 脅威の発見 | threat ジョブで、損が `threat_min` cp（既定200）以上の脅威が見つかった |

### E5.9 決定的モード

`dajo set deterministic=1`（USI では `Deterministic` オプション）のとき、1スレッドで、時間ではなくノード数で制限し、乱数を使わない。同じ入力に対して、毎回まったく同じ出力（評価値・読み筋・ノード数）を返す。DJP の動作を、決まった入出力の一覧でテストするため（§E6）。

- ルートの詰み探索など、探索の中のすべての打ち切りもノード数（または手数）だけで決め、**時間では止めない**。結果がエンジンの速さに左右されないようにするため（高速化の前後で結果が一致することを、決定的モードで確かめる。§E8 の N5）。

## E6. テスト（必須）

1. **特徴量の正解データ**：§F7 の全局面・全視点・v0/v1 で、全計算の結果が付録Bと一致すること。§F2.3 の手計算例も一致すること。
2. **差分更新**：自己対局または棋譜を使い、10万手以上で差分更新と全計算の蓄積値が毎手一致すること（駒取り・成り・駒打ち・玉移動・null move を含む）。
3. **指し手生成（perft）**：平手初期局面から、深さ1〜5で 30 / 900 / 25,470 / 719,731 / 19,861,490 になること。
4. **重みファイル**：Shikibu が書き出した `.shk` を読み込めること。ヘッダや CRC を壊したファイルは読み込みを拒否すること。
5. **量子化と推論**：Shikibu の `tools/make_engine_golden.py` が作る正解データ（局面ごとの特徴・蓄積値・最終出力・評価値）と、1ビットも違わず一致すること。
6. **USI**：将棋所と ShogiGUI に登録して対局できること。ponder（`go ponder` → `ponderhit`／`stop`）が正しく動くこと。
7. **探索**：詰将棋の問題集を解けること。Nuenagon-toy v2（Python の試作）に、同じ持ち時間で大きく勝ち越すこと。
8. **DJP**：決定的モード（§E5.9）で、決まった入出力の一覧（台本）どおりに応答すること。例：タダで駒を取られる手の `probe` が `verdict=no` と咎める手順を返す、詰めろの局面の `threat tsumero=1` が `tsumero=yes` を返す、詰将棋の局面の `mate` が正しい手数を返す、DJP を使っていても USI だけの GUI と問題なく対局できる。
9. **CPU の割り当て**：`CpuAffinity` で指定した論理CPU以外でスレッドが動かないこと（OS の機能で確認）。
10. **ベンチマーク**：`bench` コマンドで、固定の局面群を固定の深さまで探索したときの NPS を出す。

## E7. Dajo 向けの約束（USI の範囲）

DJP を使わない場合でも Dajo が Nuenagon の読みを使えるよう、次を守る。

- 反復深化の各深さの終わりと、`bestmove` の直前に、必ず次の形式の `info` を出す：
  `info depth <d> seldepth <sd> score cp <v> nodes <n> nps <nps> time <ms> pv <手順>`
  （詰みは `score mate <n>`。n は詰みまでの手数（ply）。勝ちは正、詰まされるのは負。最短の詰みでなくてもよい）
- `score cp` は手番側から見た値で、尺度は §F5（cp = z × eval_scale）。
- `go infinite` → `stop` で、直ちに（目安100ms以内）`bestmove` を返す。
- `MultiPV` オプション（既定1）に対応する。

## E8. 進め方

| マイルストーン | 内容 |
|---|---|
| N1 | Dainagon からの盤面・指し手生成・詰み探索の移植、perft（テスト3） |
| N2 | 特徴量の全計算、正解データ（テスト1） |
| N3 | 重みの読み込み・量子化・推論（テスト4・5）、差分更新（テスト2） |
| N4 | 探索の中核（§E5 の構造をすべて含む：ジョブ、スレッドプール、手ごとの記録、ヒントの表、パスの探索、出来事の通知、決定的モード）、USI と ponder（テスト6・7）、ベンチマーク（テスト10） |
| N4.1 | 中盤の時間の使い方と木の膨らみの修正（ルートの詰み探索の締め切り、王手延長、静止探索、浅い深さの枝刈り）、`score mate` の手数、`bestmove` の直前の info |
| N5 | **高速化**（探索の結果を変えずに速くする：差分更新、SIMD、メモリの確保、指し手の生成）、CPU の割り当て（テスト9）、詰み探索の `stop` への応答 |
| N5H | HalfKP 対応（§E10）：やねうら王の halfkp_256x2-32-32 の評価関数ファイルを読み、同じ探索で RayPair と比べられるようにする |
| N5.5 | 探索の改良（§E11）：指し手の生成と並べ替え、枝刈りと延長、将棋ならではの工夫。探索の木を変えてよい。N5H と比べて深く・強くなったことを確かめる |
| N6 | DJP v0（§E9）、台本によるテスト（テスト8） |

- 本戦（11月半ば）に出すかどうかは 11/9 頃に判定する。条件は「Dajo が Dainagon 単体に負け越さないこと」。
- 本戦に必要な DJP の最小構成は `hello`・`search`・`probe`・`threat`・`mate`・`cancel`・`set`・`sysinfo`。残り（`rank`・`hint`・`watch`・`promote`・`eval`）は、§E5 の構造が N4 にあれば軽く作れるので、時間があれば同時に入れる。

## E9. Dajo プロトコル（DJP v0）

Dajo（合議）が Nuenagon と Dainagon に、USI の範囲を超えた問い合わせをするための約束。**自由区画**だが、変更するときは版を上げ（§E9.2）、古い版の動作は残す。

### E9.1 原則

1. **USI と共存する。** エンジンはふつうの USI エンジンとして動き、将棋所・ShogiGUI に登録できる。`dajo hello` を受け取るまで、`dajo` で始まる命令は一切出さない。GUI は `dajo` を送らないので干渉しない。
2. **文字の1行ずつ。** 標準入出力で、1行に1つの命令または応答を書く。`ssh` 越しでもそのまま使える。
3. **ジョブ単位。** 問い合わせには番号を付け、応答にも同じ番号を付ける。複数のジョブを同時に投げられ、応答は番号で区別する。
4. **局面はジョブが持つ。** 各ジョブの末尾に局面を書く。エンジン側に「今の局面」という状態を持たせない（取り違えの事故を防ぐため）。
5. **値には必ず確かさを付ける。** 評価値には、正確な値か上限・下限か（`bound`）と、読んだ深さ（`depth`）を必ず付ける。
6. **評価は cp と勝率の両方で返す。** `wr = 1 / (1 + exp(−cp / eval_scale))`（手番側から見た勝率）。詰みは勝ちなら 1、負けなら 0。Dainagon の勝率と比べやすくするため。

### E9.2 有効化と版

```
→ dajo hello 0
← dajo hello 0 engine=Nuenagon caps=search,rank,probe,threat,mate,eval,hint,watch,promote,sysinfo
```

- 数字はプロトコルの版。エンジンは自分が対応する版のうち、要求以下で最大のものを返す。対応できなければ `dajo error 0 code=version`。
- `caps` は対応している機能の一覧（カンマ区切り）。Dajo は一覧にない命令を送らない。
- `hello` は何度送ってもよい（版の確認だけ）。

### E9.3 書式

- 1行は、半角空白で区切った語の並び。最初の語は必ず `dajo`。
- 引数は `キー=値`。値に空白を含めない。リストはカンマ区切り（例：`moves=7g7f,2g2f`）。
- 指し手は USI の表記（`7g7f`、`P*5e`、`8h2b+`）。
- 局面を書く命令では、**局面が最後**に来る：`position startpos [moves …]` または `position sfen <盤面> <手番> <持ち駒> <手数> [moves …]`（USI の `position` と同じ）。
- ジョブの番号は 1〜2147483647 の整数。番号0は USI の `go` に使う（予約）。同じ番号を同時に2つ使わない。
- 数値は10進数。時間はミリ秒、評価値は手番側から見た cp（§F5 の尺度）。
- エンジンは知らないキーを無視する（新しい版のキーが来ても壊れないように）。知らない命令には `dajo error <番号> code=unknown_command` を返す。

### E9.4 ジョブ

```
dajo job <番号> <種類> [キー=値 …] position …
```

共通のキー：

| キー | 内容 | 既定 |
|---|---|---|
| `time` | 時間の上限（ms） | なし |
| `nodes` | ノード数の上限 | なし |
| `depth` | 深さの上限 | なし |
| `infinite` | `1` なら止められるまで続ける（上限より優先） | 0 |
| `threads` | 使うスレッド数の上限 | プールの全部 |
| `priority` | 優先度（0〜9、大きいほど先） | 5 |
| `report` | 途中経過を出す間隔（`iter`＝反復ごと、`none`＝最後だけ） | `iter` |

上限がどれも無く、`infinite` でもないときは `dajo error <番号> code=no_limit` を返す。

エンジンは受け付けたら `dajo accepted <番号>` を返す。スレッド待ちのときは `dajo queued <番号>`、動き始めたら `dajo started <番号>` を返す。最後に必ず `dajo result <番号> …`（§E9.7）を1回だけ返す。

#### 種類ごとの中身

**`search`**：ふつうの探索。

| キー | 内容 |
|---|---|
| `multipv` | 上位 k 手を正確な値で求める（既定1） |
| `searchmoves` | この手だけを読む |
| `exclude` | この手を読まない |

途中経過：反復ごとに、上位 k 手それぞれについて `dajo move`（§E9.7）を出す。結果：最善手と、上位 k 手の最終の値。

**`rank`**：指定した手それぞれを、同じ深さまで正確な値で求める。

| キー | 内容 |
|---|---|
| `moves` | 評価する手（省略時は全合法手） |

結果：指定した手すべての `dajo move`（すべて同じ `depth` の `exact`）。時間切れで最後の段が終わっていなければ、最後に全手が終わった段の値を返す。

**`probe`**：ある手の評価が閾値以上かを確かめる（§E5.4 の検証）。

| キー | 内容 |
|---|---|
| `move` | 確かめる手（必須） |
| `threshold` | 閾値 T（cp）。「この手の評価 ≥ T か」を確かめる |
| `margin` | `threshold` の代わりに使う。Nuenagon が自分で最善の評価 B を求め（置換表と短い探索で）、T = B − margin とする |
| `ref` | `margin` と併用。B を自分で求めず、この値を B として使う |
| `mindepth` | この深さ未満の結論は `unknown` とする（既定4） |

結果のキー：`verdict=yes|no|unknown`、`threshold=<T>`、`score`・`bound`・`depth`。`no` のときは `pv`（この手を指した後の、相手の咎める手順）も返す。

**`threat`**：手番をパスしたとして、相手の脅威を調べる（§E5.6）。

| キー | 内容 |
|---|---|
| `compare` | `1` なら、パスしない通常の探索も同じ深さで行い、差（損の大きさ）を返す |
| `tsumero` | `1` なら、パスした後に相手の詰みがあるか（詰めろ）も詰み探索で調べる |

結果のキー：`threat_move`（相手の最善手）、`score_pass`（パスした場合の手番側から見た評価）、`compare=1` なら `score_normal` と `gain = score_normal − score_pass`、`tsumero=1` なら `tsumero=yes|no|unknown` と、`yes` のとき `mate_pv`。王手がかかっている局面では `dajo error <番号> code=in_check`。

**`mate`**：詰み探索（§E5.7）。

| キー | 内容 |
|---|---|
| `side` | `self`（手番側が詰ませられるか）／`opponent`（パスした後、相手が詰ませられるか＝詰めろ） |

結果のキー：`mate=yes|no|unknown`、`yes` なら `length`（手数）と `pv`。

**`eval`**：局面の評価（探索しない）。

```
dajo job <番号> eval [qsearch=1] positions <局面1> | <局面2> | …
```

この種類だけは、局面を `position` ではなく `positions` の後に `|` 区切りで並べる。各局面は `startpos [moves …]` または `sfen … [moves …]`。結果：局面ごとに `dajo evalres <番号> index=<i> cp=<v> wr=<p>` を返し、最後に `dajo result`。`qsearch=1` なら静止探索の値、それ以外は評価関数の値。

### E9.5 制御の命令

| 命令 | 内容 | 応答 |
|---|---|---|
| `dajo cancel <番号>` | ジョブを止める。`all` なら全部 | 止めたジョブの `dajo result … status=cancelled` |
| `dajo promote <番号> [time=…] [nodes=…] [depth=…]` | `infinite` で動いているジョブに上限を付ける。**DJP での ponder**：相手の予想手の局面を `infinite` で読ませておき、予想が当たったら promote で持ち時間を与える | `dajo promoted <番号>` |
| `dajo hint probs=<手>:<確率>,… position …` | その局面のヒント（§E5.5）を登録する。何行でも送れる | なし |
| `dajo hint clear` | ヒントを全部消す | なし |
| `dajo watch on [events=…] [swing=…] [threat_min=…]` | 出来事の通知（§E5.8）を有効にする。`events` は `iter,best,mate,swing,threat` から選ぶ（既定は全部） | なし |
| `dajo watch off` | 通知を止める | なし |
| `dajo set <キー>=<値> …` | 設定を変える（下の表） | `dajo set ok` または `dajo error 0 code=bad_arg key=…` |
| `dajo newgame` | 新しい対局（置換表の世代を進め、ヒントを消す） | なし |
| `dajo sync` | それまでに送った命令がすべて処理されたら応答する | `dajo synced` |
| `dajo sysinfo` | CPU の構成を返す | `dajo sysinfo logical=… physical=… numa=… simd=… threads=… affinity=…` |

`dajo set` のキー：

| キー | 内容 |
|---|---|
| `threads` | スレッドプールの大きさ（動いているジョブは、止めずに次の反復から反映） |
| `affinity` | `CpuAffinity` と同じ書式 |
| `physical_only` | `UsePhysicalCoresOnly` と同じ（0/1） |
| `hash` | 置換表の大きさ（MB）。ジョブが動いていないときだけ |
| `draw_value` | 引き分けの評価値 |
| `max_ply` | 最大手数 |
| `hint_weight` | ヒントの強さ（0〜1、既定1） |
| `hint_lmr_threshold` | §E5.5 |
| `deterministic` | 決定的モード（§E5.9） |
| `eval_scale` | 勝率への変換に使うスケール（既定は重みファイルの値） |

### E9.6 スレッドと CPU（1台の PC で合議するために）

- Nuenagon の探索スレッドの総数はスレッドプールの大きさ（`Threads`／`dajo set threads`）で決まり、ジョブはその中から割り当てられる。
- Dajo は、起動時に Nuenagon と Dainagon の `sysinfo` を見て、**互いに重ならない論理CPUの集合**を決め、Nuenagon には `dajo set affinity=…`、Dainagon には同等の設定（§E9.9）を送る。
- 対局中に配分を変えてよい（例：相手の手番中は Dainagon の ponder に多く回す）。`dajo set threads=…` は、動いているジョブを止めずに次の反復から反映する。

### E9.7 応答の共通の形

```
dajo move <番号> move=<手> score=<cp> wr=<勝率> bound=<exact|lower|upper> depth=<d> seldepth=<sd> nodes=<n> [mate=<±手数>] pv=<手,手,…>
dajo info <番号> depth=<d> nodes=<n> nps=<nps> time=<ms> hashfull=<‰>
dajo event <番号> type=<iter|best|mate|swing|threat> …（中身は出来事ごと）
dajo result <番号> status=<done|cancelled|timeout|error> time=<ms> nodes=<n> …（種類ごとのキー）
dajo error <番号> code=<コード> [key=…] [msg=<空白なしの説明>]
```

- `score` は手番側から見た cp。詰みは `mate=+n`（n 手で勝ち）／`mate=−n`（n 手で負け）を付け、`score` は ±30000 前後の詰みの値にする。
- `time` はジョブを受け付けてからの経過時間。
- エラーのコード：`unknown_command`、`bad_arg`、`version`、`no_limit`、`illegal_position`、`illegal_move`、`in_check`、`no_such_job`、`duplicate_id`、`busy`。

### E9.8 例

```
→ dajo hello 0
← dajo hello 0 engine=Nuenagon caps=search,rank,probe,threat,mate,eval,hint,watch,promote,sysinfo
→ dajo set threads=8 affinity=8-15
← dajo set ok
→ dajo job 1 search infinite=1 threads=6 multipv=3 position startpos moves 7g7f 3c3d
← dajo accepted 1
← dajo started 1
→ dajo job 2 probe move=8h2b+ margin=200 time=800 threads=2 position startpos moves 7g7f 3c3d
← dajo accepted 2
← dajo started 2
← dajo move 1 move=2g2f score=35 wr=0.53 bound=exact depth=12 seldepth=18 nodes=2310455 pv=2g2f,8c8d,2f2e
← dajo result 2 status=done time=640 nodes=1402211 verdict=yes threshold=-170 score=-120 bound=lower depth=11
→ dajo cancel 1
← dajo result 1 status=cancelled time=2051 nodes=5122011 bestmove=2g2f score=31 bound=exact depth=14
```

### E9.9 Dainagon 側の DJP（任意）

Dainagon（MCTS）が DJP に対応すると、Dajo は Nuenagon の結果を Dainagon の探索に反映できる（協力の形 F）。Dainagon 側は、共同開発者の判断で対応するか、合議用に改造して対応する。対応しない場合、Dajo は USI の範囲（`MultiPV` と `info`）で取れる情報だけを使う。

| 命令 | 内容 | 応答 |
|---|---|---|
| `dajo hello 0` | 有効化（§E9.2） | `dajo hello 0 engine=Dainagon caps=…` |
| `dajo rootstats [top=k]` | 探索中または直前の探索のルートの統計 | 手ごとに `dajo root move=<手> visits=<n> q=<勝率> prior=<方策の確率>`、最後に `dajo rootstats_end total=<総訪問数>` |
| `dajo treestats [top=k] [depth=d]` | ルートから深さ d までの主要な節点の統計（ヒントを作るため） | 節点ごとに `dajo node path=<手,手,…> visits=… q=… policy=<手>:<確率>,…`、最後に `dajo treestats_end` |
| `dajo exclude moves=<手,…>` | 探索中のルートで、指定した手を以後選ばない | `dajo excluded` |
| `dajo bias move=<手> value=<勝率の補正>` | ルートの指定した手の評価に補正を加える（例：Nuenagon が損を見つけた手を下げる） | `dajo biased` |
| `dajo set threads=… affinity=…` | Dainagon が使う CPU スレッドと論理CPU（§E9.6） | `dajo set ok` |
| `dajo sysinfo` | §E9.5 と同じ | 同じ |

### E9.10 協力の形と、使う命令

| 協力の形 | 中身 | 使う命令 |
|---|---|---|
| A. 拒否権（検証） | Dainagon の候補手に戦術的な咎めがないか確かめる | `probe`、`rank` |
| B. 脅威の指摘 | 相手に手番を渡したら何をされるか（詰めろ・駒取りの狙い） | `threat`、`mate side=opponent` |
| C. 詰みの委任 | 自分・相手の詰みを専用の探索で確かめる | `mate` |
| D. 誘導 | Dainagon の方策を Nuenagon の並べ替えと枝刈りに使う | `hint`（＋Dainagon の `rootstats`・`treestats`） |
| E. 時間の配分 | 一致すれば早く指し、割れたら延ばす | `watch`、`search`、`cancel` |
| F. 逆方向の注入 | Nuenagon の結論を Dainagon の探索に反映する | Dainagon の `exclude`・`bias` |
| G. ponder | 相手の予想手（Dainagon の上位の予想を複数でもよい）の局面を先に読んでおく | `search infinite=1`、`promote`、`cancel` |

## E10. HalfKP 対応（比較実験用）

RayPair の構造そのものの強さを確かめるため、同じ探索（Nuenagon）で、広く使われている HalfKP の評価関数とも動くようにする。
同じ教師データ・同じくらいの学習量で作った RayPair と HalfKP を、ノード数を固定した対局で比べれば、探索の差を除いた評価関数の差が測れる。
また、同じ HalfKP の評価関数で Nuenagon とやねうら王を比べれば、探索の差が測れる。

- 形式：やねうら王の NNUE（halfkp_256x2-32-32、ファイル名は任意）。`EvalFile` の先頭4バイトが 0x7AF32F16 なら HalfKP として読み、それ以外は .shk として読む。
- 特徴量・推論・評価値の定義、ファイルの並びと検査は、テスト（`tests/test_n5h_acceptance.py`、`tests/halfkp_ref.py`、`tests/halfkp_nnbin.py`）の冒頭のコメントのとおり。やねうら王と1点も違わない評価値を出すこと。
- 評価値は `raw / FV_SCALE`（0 の方向への切り捨て）。探索の中での扱いは RayPair と同じ。
- この節は自由区画。RayPair（第F部）の定義と、RayPair での探索の結果は変えない。

## E11. 探索の改良（N5.5 以降）

N5 までは「探索の結果を変えずに速くする」だったが、N5.5 からは探索の木そのものを変えてよい。良し悪しは、テストでは前の版（N5H）との深さ・強さの比較で、本番では利用者の対局（nuematch、本物の評価関数）で決める。

- 対象：指し手の生成（段階的な生成、合法性の確認の後回しなど）、並べ替え（履歴、連続履歴、カウンター手、取る手の履歴など）、枝刈り（LMR の表、reverse futility、null move、LMP、SEE、razoring、ProbCut など）、延長（singular extension など）、将棋ならではの工夫（全ノードでの1手詰めの判定、遠い打つ手の枝刈り、優等局面・劣等局面など）、時間の使い方。
- 守ること：USI・ponder・決定的モード（§E5.9）・`info` の約束（§E7）・DJP の受け口（§E5）、合法手しか指さないこと、千日手と入玉宣言の扱い、RayPair と HalfKP の評価値の計算（第F部・§E10）。
- **入り切り**：手法は、できるだけ USI の check のオプション（名前は `Search` で始める）で入り切りできるようにする。同じ実行ファイルのまま、対局で手法ごとの効き目を測るため。
- **他のエンジンの参照**：やねうら王・Stockfish などの手法を参考にしてよい。ただし**コードは写さない**（どちらも GPL。写すと Nuenagon が GPL の派生物になり、WCSC で「フルスクラッチ」と名乗れなくなる）。考え方を理解したうえで、自分の書き方で実装し、何を参考にしたかを報告に書く。

---

# 付録

## 付録A　特徴量の参照実装（Python、凍結区画の一部）

可読性を優先した遅い実装。§F2 と食い違う場合は**作業を止めて報告**すること（どちらかを勝手に正としない）。入力は SFEN 文字列。

```python
# RayPair reference implementation (readable, slow). Frozen-contract oracle.
import hashlib

PIECE_ORDER = ["P","L","N","S","G","B","R","K","+P","+L","+N","+S","+B","+R"]
HAND_ORDER  = ["P","L","N","S","G","B","R"]
HAND_MAX    = [18,4,4,4,4,2,2]
HAND_OFF    = [0,18,22,26,30,34,36]
A1_BASE, A2_BASE, B1_BASE = 0, 2268, 2344
B1_LOCAL = 12544  # 28*28*4*4

def parse_sfen(sfen):
    parts = sfen.split()
    rows = parts[0].split("/"); assert len(rows) == 9
    board = [[None]*9 for _ in range(9)]
    for y, row in enumerate(rows):
        x = 0; promo = False
        for ch in row:
            if ch.isdigit(): x += int(ch); continue
            if ch == "+": promo = True; continue
            color = 0 if ch.isupper() else 1
            board[y][x] = (color, ("+" if promo else "") + ch.upper()); x += 1; promo = False
        assert x == 9, row
    stm = 0 if parts[1] == "b" else 1
    hands = [[0]*7, [0]*7]
    if parts[2] != "-":
        n = 0
        for ch in parts[2]:
            if ch.isdigit(): n = n*10 + int(ch); continue
            hands[0 if ch.isupper() else 1][HAND_ORDER.index(ch.upper())] += (n if n else 1); n = 0
    return board, stm, hands

def view(board, hands, persp):
    vb = [[None]*9 for _ in range(9)]
    for y in range(9):
        for x in range(9):
            p = board[y][x]
            if p is None: continue
            color, pt = p
            yy, xx = (y, x) if persp == 0 else (8-y, 8-x)
            vb[yy][xx] = PIECE_ORDER.index(pt) + (0 if color == persp else 14)
    return vb, [hands[persp], hands[1-persp]]

def lines(axis):
    if axis == 0:
        for x in range(9): yield [(y, x) for y in range(9)]
    elif axis == 1:
        for y in range(9): yield [(y, x) for x in range(9)]
    elif axis == 2:
        for c in range(-8, 9): yield [(y, y+c) for y in range(9) if 0 <= y+c < 9]
    else:
        for s in range(17): yield [(y, s-y) for y in range(9) if 0 <= s-y < 9]

def db_of(d): return 0 if d == 1 else 1 if d == 2 else 2 if d <= 4 else 3

def num_features(version): return 2344 + (1 if version == 0 else 9)*B1_LOCAL + 112

def features(sfen, persp, version):
    board, stm, hands = parse_sfen(sfen)
    vb, vh = view(board, hands, persp)
    out = []
    for y in range(9):
        for x in range(9):
            if vb[y][x] is not None: out.append(A1_BASE + vb[y][x]*81 + y*9 + x)
    for side in range(2):
        for h in range(7):
            assert vh[side][h] <= HAND_MAX[h]
            for k in range(vh[side][h]): out.append(A2_BASE + side*38 + HAND_OFF[h] + k)
    for axis in range(4):
        for ln in lines(axis):
            occ = [(y, x) for (y, x) in ln if vb[y][x] is not None]
            for (ya, xa), (yb, xb) in zip(occ, occ[1:]):
                d = (xb - xa) if axis == 1 else (yb - ya)
                assert d >= 1
                local = vb[ya][xa]*448 + vb[yb][xb]*16 + axis*4 + db_of(d)
                region = 0 if version == 0 else (ya//3)*3 + (xa//3)
                out.append(B1_BASE + region*B1_LOCAL + local)
    b2 = B1_BASE + (1 if version == 0 else 9)*B1_LOCAL
    for y in range(9):
        for x in range(9):
            pc = vb[y][x]
            if pc not in (2, 16): continue
            s = 0 if pc == 2 else 1
            ty = y-2 if s == 0 else y+2
            for lr, tx in ((0, x-1), (1, x+1)):
                if 0 <= ty < 9 and 0 <= tx < 9 and vb[ty][tx] is not None:
                    out.append(b2 + s*56 + vb[ty][tx]*2 + lr)
    return sorted(out)

def digest(idx): return hashlib.sha256(",".join(map(str, idx)).encode()).hexdigest()[:16]
```

## 付録B　正解データの全リスト

各リストは昇順・重複込み。

#### RayPair_v0 / P1 / 先手視点（159個）

```
54,55,56,57,58,59,60,61,62,153,161,235,241,317,321,399,401,469,556,643,1152,1153,1154,1155,1156,1157,1158,1159,1160,1215,1223,1297,1303,1379,1383,1461,1463,1555,1630,1705,2348,2348,2348,2348,2348,2348,2348,2348,2361,2361,2385,2389,2393,2393,2401,2405,2409,2409,2417,2417,2421,2421,2424,2432,2436,2440,2448,2452,2457,2465,2469,2828,3260,3292,3724,3756,4188,4252,4612,4616,4640,4687,5056,5064,5092,5548,8618,8618,8618,8618,8618,8618,8618,8618,8618,8626,8626,8626,8626,8626,8630,8630,8630,8630,8630,8844,8844,8844,8844,8844,8844,8844,8844,9289,9289,9324,9380,9392,9745,9749,9756,9788,9816,9832,10185,10185,10193,10197,10220,10252,10272,10292,10633,10633,10641,10641,10645,10645,10684,10748,11080,11088,11092,11528,11536,11540,11615,11977,11985,11989,12044,14888,14888,14889,14889,14972,14972,14973,14973
```

#### RayPair_v0 / P1 / 後手視点（159個）

```
54,55,56,57,58,59,60,61,62,153,161,235,241,317,321,399,401,469,556,643,1152,1153,1154,1155,1156,1157,1158,1159,1160,1215,1223,1297,1303,1379,1383,1461,1463,1555,1630,1705,2348,2348,2348,2348,2348,2348,2348,2348,2361,2361,2385,2389,2393,2393,2401,2405,2409,2409,2417,2417,2421,2421,2424,2432,2436,2440,2448,2452,2457,2465,2469,2828,3260,3292,3724,3756,4188,4252,4612,4616,4640,4687,5056,5064,5092,5548,8618,8618,8618,8618,8618,8618,8618,8618,8618,8626,8626,8626,8626,8626,8630,8630,8630,8630,8630,8844,8844,8844,8844,8844,8844,8844,8844,9289,9289,9324,9380,9392,9745,9749,9756,9788,9816,9832,10185,10185,10193,10197,10220,10252,10272,10292,10633,10633,10641,10641,10645,10645,10684,10748,11080,11088,11092,11528,11536,11540,11615,11977,11985,11989,12044,14888,14888,14889,14889,14972,14972,14973,14973
```

#### RayPair_v0 / P2 / 先手視点（157個）

```
47,54,55,57,58,59,60,61,62,153,161,235,241,317,321,399,401,469,556,643,1152,1153,1154,1155,1156,1157,1158,1159,1160,1215,1223,1297,1303,1379,1383,1461,1463,1555,1630,1705,2348,2348,2348,2348,2348,2348,2349,2352,2356,2361,2361,2385,2389,2393,2394,2401,2405,2409,2409,2417,2417,2421,2421,2424,2432,2440,2448,2452,2457,2469,2828,3260,3292,3724,3756,4188,4252,4612,4616,4640,4687,5056,5064,5092,5548,8618,8618,8618,8618,8618,8618,8618,8618,8618,8626,8626,8626,8626,8626,8630,8630,8630,8630,8711,8844,8844,8844,8844,8844,8844,8844,8844,9289,9289,9324,9380,9392,9745,9749,9756,9788,9816,9832,10185,10185,10193,10197,10220,10252,10272,10292,10633,10633,10641,10641,10645,10645,10684,10748,11080,11088,11092,11528,11536,11540,11615,11977,11985,11989,12044,14888,14888,14889,14972,14972,14973,14973
```

#### RayPair_v0 / P2 / 後手視点（157個）

```
54,55,56,57,58,59,60,61,62,153,161,235,241,317,321,399,401,469,556,643,1152,1153,1154,1155,1156,1157,1159,1160,1167,1215,1223,1297,1303,1379,1383,1461,1463,1555,1630,1705,2348,2348,2348,2348,2348,2348,2348,2348,2361,2361,2385,2389,2393,2393,2401,2405,2409,2409,2417,2417,2421,2421,2424,2432,2436,2440,2448,2452,2457,2465,2469,2828,3260,3292,3724,3756,4188,4252,4612,4616,4640,4687,5056,5064,5092,5548,8618,8618,8618,8618,8618,8618,8618,8618,8618,8626,8626,8626,8626,8626,8630,8630,8630,8630,8844,8844,8844,8844,8844,8844,8845,8848,8852,9289,9289,9324,9380,9392,9745,9749,9756,9788,9816,9832,10185,10186,10193,10197,10220,10252,10272,10292,10633,10633,10641,10641,10645,10645,10684,10748,10871,11080,11088,11528,11536,11540,11615,11977,11989,12044,14888,14888,14889,14889,14972,14973,14973
```

#### RayPair_v0 / P3 / 先手視点（145個）

```
47,51,54,55,57,58,59,61,62,153,161,202,241,307,311,389,401,556,642,1152,1154,1156,1157,1159,1162,1167,1169,1215,1223,1297,1303,1398,1401,1461,1473,1630,1714,2302,2306,2340,2348,2348,2348,2348,2349,2349,2350,2352,2352,2356,2356,2361,2361,2385,2392,2392,2400,2400,2409,2416,2417,2420,2421,2440,2452,2457,2469,2910,3241,3260,3302,3346,3716,3752,3756,3789,4173,4190,4256,5056,5064,5549,8617,8618,8618,8618,8618,8618,8618,8626,8626,8629,8630,8630,8630,8649,8657,8844,8845,8845,8847,8848,8848,8848,8852,8852,8892,8892,9289,9290,9324,9349,9392,9737,9756,9793,9805,9812,9832,9962,9970,10005,10184,10188,10188,10640,10644,10670,10680,10681,10752,11529,11536,11540,11646,11976,11984,12036,12045,14889,14917,14922,14972,14973,14978
```

#### RayPair_v0 / P3 / 後手視点（145個）

```
45,47,52,55,57,58,60,62,153,161,235,241,299,302,389,401,556,634,1152,1153,1155,1156,1157,1159,1160,1163,1167,1215,1223,1297,1336,1389,1393,1461,1473,1630,1706,2268,2302,2340,2348,2349,2349,2351,2352,2352,2352,2356,2356,2361,2362,2377,2392,2396,2396,2416,2420,2441,2448,2452,2456,2464,2828,3260,3310,3692,3692,3717,3729,3752,3753,3812,4173,4180,4253,5056,5064,5552,5582,8617,8618,8618,8618,8618,8618,8618,8626,8626,8629,8630,8630,8630,8666,8674,8844,8844,8844,8844,8845,8845,8846,8848,8848,8852,8852,8873,9289,9289,9324,9348,9392,9513,9521,9573,9745,9805,9832,10184,10184,10192,10192,10230,10254,10633,10640,10641,10644,10645,10680,10684,10749,11528,11540,11570,11581,11977,11989,11998,12048,14888,14889,14895,14944,14951,14972
```

#### RayPair_v0 / P4 / 先手視点（125個）

```
39,45,47,49,51,52,55,62,153,161,202,235,299,389,634,661,1155,1159,1161,1165,1167,1169,1171,1215,1223,1303,1325,1400,1473,1717,2246,2268,2294,2295,2298,2302,2304,2306,2336,2340,2348,2349,2349,2349,2352,2352,2352,2356,2356,2361,2362,2377,2380,2392,2396,2416,2421,2457,2465,2784,2788,2828,3240,3263,3266,3301,3717,3752,4126,4180,4253,6153,6164,6208,6221,8617,8617,8617,8617,8618,8618,8621,8624,8625,8628,8628,8629,8629,8648,8845,8845,8848,8848,8848,8852,8877,8884,8893,9106,9290,9290,9327,9412,9513,9520,9741,9748,9756,9812,9848,10189,10192,10196,10394,10633,10640,10692,10748,11798,11976,14446,14564,14895,14916,14923
```

#### RayPair_v0 / P4 / 後手視点（125個）

```
43,45,47,49,53,55,59,153,161,213,235,300,389,631,1074,1152,1159,1162,1163,1165,1167,1169,1175,1215,1223,1303,1336,1401,1473,1714,1849,2268,2298,2302,2306,2332,2333,2336,2340,2342,2349,2349,2352,2352,2352,2356,2362,2362,2381,2388,2397,2400,2404,2409,2416,2456,2697,2708,2828,3245,3252,3263,3693,3764,4048,4180,4493,5508,5512,5548,8218,8400,8404,8446,8617,8617,8617,8617,8618,8618,8621,8624,8625,8628,8628,8629,8629,8649,8656,8830,8844,8845,8845,8845,8848,8848,8848,8852,8852,8872,9289,9290,9327,9330,9349,9512,9538,9638,9737,9740,9756,9812,10184,10188,10229,10640,10645,10680,11972,11977,11985,12045,14945,14950,14978
```

#### RayPair_v1 / P1 / 先手視点（159個）

```
54,55,56,57,58,59,60,61,62,153,161,235,241,317,321,399,401,469,556,643,1152,1153,1154,1155,1156,1157,1158,1159,1160,1215,1223,1297,1303,1379,1383,1461,1463,1555,1630,1705,8618,8618,8618,8626,8626,8626,8844,8844,8844,9289,9324,9392,9745,9788,9832,10185,10193,10252,10292,11528,11536,11540,11615,21162,21162,21162,21170,21170,21174,21174,21388,21388,21388,23177,23177,23185,23185,23189,23189,23228,23292,24521,24529,24533,24588,33706,33706,33706,33718,33718,33718,33932,33932,34377,34468,34837,34844,34904,35273,35285,35308,35360,36168,36176,36180,77612,77612,77612,77625,77657,77681,77688,77696,77700,77729,78092,78556,79020,79876,79880,79904,79951,90156,90156,90156,90193,90197,90209,90213,90217,90217,90225,90229,90265,91996,92060,93356,102700,102700,102713,102745,102773,102792,102800,102804,102821,103612,104076,105408,105416,105444,115240,115240,115241,115241,115324,115324,115325,115325
```

#### RayPair_v1 / P1 / 後手視点（159個）

```
54,55,56,57,58,59,60,61,62,153,161,235,241,317,321,399,401,469,556,643,1152,1153,1154,1155,1156,1157,1158,1159,1160,1215,1223,1297,1303,1379,1383,1461,1463,1555,1630,1705,8618,8618,8618,8626,8626,8626,8844,8844,8844,9289,9324,9392,9745,9788,9832,10185,10193,10252,10292,11528,11536,11540,11615,21162,21162,21162,21170,21170,21174,21174,21388,21388,21388,23177,23177,23185,23185,23189,23189,23228,23292,24521,24529,24533,24588,33706,33706,33706,33718,33718,33718,33932,33932,34377,34468,34837,34844,34904,35273,35285,35308,35360,36168,36176,36180,77612,77612,77612,77625,77657,77681,77688,77696,77700,77729,78092,78556,79020,79876,79880,79904,79951,90156,90156,90156,90193,90197,90209,90213,90217,90217,90225,90229,90265,91996,92060,93356,102700,102700,102713,102745,102773,102792,102800,102804,102821,103612,104076,105408,105416,105444,115240,115240,115241,115241,115324,115324,115325,115325
```

#### RayPair_v1 / P2 / 先手視点（157個）

```
47,54,55,57,58,59,60,61,62,153,161,235,241,317,321,399,401,469,556,643,1152,1153,1154,1155,1156,1157,1158,1159,1160,1215,1223,1297,1303,1379,1383,1461,1463,1555,1630,1705,8618,8618,8618,8626,8626,8626,8844,8844,8844,9289,9324,9392,9745,9788,9832,10185,10193,10252,10292,11528,11536,11540,11615,21162,21162,21162,21170,21170,21174,21174,21388,21388,21388,23177,23177,23185,23185,23189,23189,23228,23292,24521,24529,24533,24588,33706,33706,33706,33718,33718,33799,33932,33932,34377,34468,34837,34844,34904,35273,35285,35308,35360,36168,36176,36180,39984,39988,40026,77612,77613,77625,77681,77688,77696,78092,78556,79020,79876,79880,79904,79951,90156,90156,90156,90193,90197,90209,90213,90217,90217,90225,90229,90265,91996,92060,93356,102700,102700,102713,102745,102773,102792,102800,102804,102821,103612,104076,105408,105416,105444,115240,115240,115241,115324,115324,115325,115325
```

#### RayPair_v1 / P2 / 後手視点（157個）

```
54,55,56,57,58,59,60,61,62,153,161,235,241,317,321,399,401,469,556,643,1152,1153,1154,1155,1156,1157,1159,1160,1167,1215,1223,1297,1303,1379,1383,1461,1463,1555,1630,1705,8618,8618,8618,8626,8626,8626,8844,8844,8844,9289,9324,9392,9745,9788,9832,10185,10193,10252,10292,11528,11536,11540,11615,21162,21162,21162,21170,21170,21174,21174,21388,21388,21389,21392,23177,23177,23185,23185,23189,23189,23228,23292,24521,24533,24588,33706,33706,33718,33932,33940,34377,34468,34837,34844,34904,35274,35285,35308,35360,35959,36168,36176,71338,71350,77612,77612,77612,77625,77657,77681,77688,77696,77700,77729,78092,78556,79020,79876,79880,79904,79951,90156,90156,90156,90193,90197,90209,90213,90217,90217,90225,90229,90265,91996,92060,93356,102700,102700,102713,102745,102773,102792,102800,102804,102821,103612,104076,105408,105416,105444,115240,115240,115241,115241,115324,115325,115325
```

#### RayPair_v1 / P3 / 先手視点（145個）

```
47,51,54,55,57,58,59,61,62,153,161,202,241,307,311,389,401,556,642,1152,1154,1156,1157,1159,1162,1167,1169,1215,1223,1297,1303,1398,1401,1461,1473,1630,1714,2302,2306,2340,8618,8618,8657,8845,8848,8852,8892,9289,9324,9392,9793,9805,9832,11529,11536,11540,11646,21162,21170,21174,21174,21193,21388,21392,21436,22506,22514,22732,23214,23225,23296,24520,24528,24580,24589,33706,33936,33940,34378,34437,34825,34844,34900,35093,35272,35276,35728,35732,35768,39982,39984,39988,40041,46250,46258,46479,53417,53478,53522,65072,65076,71337,71338,71349,71350,71565,77612,77613,77625,77656,77664,77680,78174,78980,79020,79454,79520,90156,90156,90157,90193,90200,90208,90225,90228,90265,90277,91560,91597,91981,93357,102700,102713,102773,102792,102804,103612,105408,105416,115241,115269,115274,115324,115325,115330
```

#### RayPair_v1 / P3 / 後手視点（145個）

```
45,47,52,55,57,58,60,62,153,161,235,241,299,302,389,401,556,634,1152,1153,1155,1156,1157,1159,1160,1163,1167,1215,1223,1297,1336,1389,1393,1461,1473,1630,1706,2268,2302,2340,8618,8618,8626,8844,8845,8848,9289,9324,9392,9745,9805,9832,11528,11540,11570,11581,21162,21170,21174,21210,21388,21388,21389,21392,21396,21417,22728,22736,22798,23185,23189,23224,23293,24521,24533,24542,24592,33706,33706,33718,33932,33940,34377,34436,35272,35280,35318,35721,35728,35732,35772,39981,39983,39984,39984,39988,39994,40024,46249,46261,46306,46478,59689,59697,59749,65072,65076,65161,71338,71350,77641,77660,77680,78092,78574,78956,78981,79016,79444,79517,90156,90204,90228,90264,90272,91500,91537,91561,91620,91981,93360,93390,102701,102713,102800,102804,103612,105408,105416,115240,115241,115247,115296,115303,115324
```

#### RayPair_v1 / P4 / 先手視点（125個）

```
39,45,47,49,51,52,55,62,153,161,202,235,299,389,634,661,1155,1159,1161,1165,1167,1169,1171,1215,1223,1303,1325,1400,1473,1717,2246,2268,2294,2295,2298,2302,2304,2306,2336,2340,9106,9290,9327,18697,18708,18752,18765,21161,21392,21428,21437,22733,22736,22740,22938,33706,33936,33940,34378,34500,34844,34900,34936,35721,35728,35780,35836,36886,37064,39981,39981,39984,39988,39994,40024,40097,46249,46249,46253,46256,46260,46480,46509,47145,47152,47373,47380,52525,52528,52532,52556,52597,52633,52960,53416,53442,53477,58801,58804,58824,59021,65068,65072,65508,71337,71338,71349,71349,71565,77641,77660,77680,78092,78527,78981,79016,79390,79444,79517,102254,102372,102713,115247,115268,115275
```

#### RayPair_v1 / P4 / 後手視点（125個）

```
43,45,47,49,53,55,59,153,161,213,235,300,389,631,1074,1152,1159,1162,1163,1165,1167,1169,1175,1215,1223,1303,1336,1401,1473,1714,1849,2268,2298,2302,2306,2332,2333,2336,2340,2342,8618,8830,8848,9289,9327,9330,20762,20944,20948,20990,24516,24521,24529,24589,33705,33936,33940,34378,34437,34825,34844,34900,35272,35276,35317,35728,35733,35768,39981,39981,39984,39988,39994,40032,40041,46249,46250,46257,46261,46476,46477,52528,52557,52580,52873,58793,58797,58804,58805,58832,59021,59024,59048,59688,59714,59814,59916,65072,65082,65108,65965,65972,71337,71344,71348,71369,71565,71572,77661,77680,77720,78092,78527,79444,79757,80772,80776,80812,90516,91501,91572,91856,115297,115302,115330
```

## 付録C　決定事項の記録

| 項目 | 決定 |
|---|---|
| 名前 | 学習器 Shikibu、エンジン Nuenagon、作者 Harumichi-Toshiki |
| 体制 | 本書1つを両リポジトリに置き、2つの Claude Code が別々に実装。一致は書面（正解データ）で担保 |
| 優先順位 | 特徴量の完全一致と凍結 ＞ エンジンの効率 |
| 特徴量 | RayPair_v0（15,000次元）と RayPair_v1（領域9区分、115,352次元）を両方定義 |
| ネットワーク | v0：256→16→16→1、v1：256→32→32→1。活性化はすべて ClippedReLU |
| 重みの受け渡し | float32（`.shk`）。量子化はエンジンが読み込み時に行う |
| 教師データ | 他のエンジンの評価値を付けた PSV（蒸留データ）。どのデータを使うかは学習ごとに決める。eval_scale はデータから推定し、ヘッダに記録 |
| 学習環境 | Rust ＋ PyTorch、Google Colab（L4）、Drive からシャードを先読み |
| エンジン | C++、Dainagon エンジンの盤面・指し手生成を流用・改造可、USI 対応（将棋所・ShogiGUI） |
| 合議の通信 | USI と共存する独自プロトコル DJP v0（文字の1行ずつ、ジョブ単位）。Dainagon 側は任意対応（対応できなければ合議用に改造） |
| ponder | USI の標準どおり必須。DJP では infinite のジョブ＋promote で、複数の予想手にも対応 |
| CPU | PC は1台。Nuenagon は使う論理CPU・物理コアのみの指定に対応し、Dainagon と重ならないよう Dajo が配分する |

## 付録D　改訂履歴

| 版 | 日付 | 内容 |
|---|---|---|
| v1.0 | 2026-10-20 | 初版 |
| v1.1 | 2026-10-21 | 教師データの記述を修正。§E4 に丸めの方向と評価値の計算式を明記。**凍結区画（第F部）の変更なし** |
| v1.2 | 2026-10-21 | ponder（§E2.2）と CPU の割り当て（§E2.3・§E2.4）を追加。探索の構造（§E5）を、ジョブ・スレッドプール・手ごとの記録・ヒント・パスの探索・出来事の通知・決定的モードを含む形に改訂。Dajo プロトコル DJP v0（§E9）を新設。テスト（§E6）と進め方（§E8）を更新（N6 を新設）。**凍結区画（第F部）の変更なし** |
| v1.3 | 2026-10-21 | 特定の教師データ・保存場所に依存する記述を除き、汎用の書き方に改めた（§F5・§S2・付録C）。**凍結区画の定義（特徴量・ネットワーク・ファイル形式・正解データ）の変更なし** |
| v1.4 | 2026-10-21 | 進め方（§E8）に N4.1 を追加し、N5 を高速化を中心とする内容に改めた。決定的モードでは時間で打ち切らないこと（§E5.9）、`score mate` の n が手数であること（§E7）を明記。**凍結区画（第F部）の変更なし** |
| v1.5 | 2026-10-22 | HalfKP 対応（§E10、オプション `FV_SCALE`、進め方の N5H）を追加。**凍結区画（第F部）の変更なし** |
| v1.6 | 2026-10-22 | 探索の改良（§E11、進め方の N5.5）を追加。N5 のテストから「N4.1 と探索の結果が同じ」「N4.1 の 2 倍の速さ」を外した。**凍結区画（第F部）の変更なし** |
